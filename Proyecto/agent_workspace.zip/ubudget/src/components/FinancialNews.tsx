import React, { useState, useEffect } from 'react';
import { 
  Newspaper, 
  Clock, 
  ExternalLink, 
  TrendingUp,
  TrendingDown,
  DollarSign,
  Globe,
  Filter,
  RefreshCw
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { NewsArticle } from '../types';

interface NewsWithCategory extends NewsArticle {
  category: 'economia' | 'bolsa' | 'empresas' | 'internacional' | 'cripto';
  priority: 'high' | 'medium' | 'low';
}

const FinancialNews: React.FC = () => {
  const [news, setNews] = useState<NewsWithCategory[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState(false);

  // Noticias simuladas realistas para Colombia
  const simulatedNews: NewsWithCategory[] = [
    {
      title: "Ecopetrol anuncia inversión de $8 billones para transición energética",
      description: "La petrolera estatal planea destinar recursos significativos a proyectos de energías renovables y reducción de emisiones de carbono para los próximos cinco años.",
      url: "#",
      source: "Portafolio",
      publishedAt: new Date(Date.now() - Math.random() * 3600000).toISOString(),
      urlToImage: "/images/financial-news.jpg",
      category: 'empresas',
      priority: 'high'
    },
    {
      title: "Banco de la República mantiene tasa de interés en 10.75%",
      description: "La junta directiva decidió mantener la tasa de política monetaria tras evaluar las condiciones de inflación y crecimiento económico del país.",
      url: "#",
      source: "El Tiempo",
      publishedAt: new Date(Date.now() - Math.random() * 7200000).toISOString(),
      urlToImage: "/images/financial-charts.png",
      category: 'economia',
      priority: 'high'
    },
    {
      title: "Bancolombia reporta utilidades récord en el primer trimestre",
      description: "El principal banco privado del país registró ganancias superiores a $1.2 billones, impulsadas por el crecimiento en cartera comercial y consumo.",
      url: "#",
      source: "La República",
      publishedAt: new Date(Date.now() - Math.random() * 10800000).toISOString(),
      urlToImage: "/images/investments.png",
      category: 'bolsa',
      priority: 'medium'
    },
    {
      title: "Inflación colombiana se ubica en 5.8% en marzo",
      description: "El DANE reportó una inflación mensual de 0.92%, con los alimentos y la vivienda como los componentes que más contribuyeron al incremento de precios.",
      url: "#",
      source: "DANE",
      publishedAt: new Date(Date.now() - Math.random() * 14400000).toISOString(),
      urlToImage: "/images/financial-charts.png",
      category: 'economia',
      priority: 'high'
    },
    {
      title: "Grupo Argos incrementa inversión en infraestructura sostenible",
      description: "La compañía destinará $2.5 billones adicionales para proyectos de cemento verde y energías renovables en Colombia y Estados Unidos.",
      url: "#",
      source: "Semana",
      publishedAt: new Date(Date.now() - Math.random() * 18000000).toISOString(),
      urlToImage: "/images/real-estate.png",
      category: 'empresas',
      priority: 'medium'
    },
    {
      title: "Bitcoin supera los $45,000 dólares en mercados internacionales",
      description: "La criptomoneda principal experimenta un rally alcista tras declaraciones positivas de la Reserva Federal estadounidense sobre la regulación crypto.",
      url: "#",
      source: "CoinDesk",
      publishedAt: new Date(Date.now() - Math.random() * 21600000).toISOString(),
      urlToImage: "/images/financial-charts.png",
      category: 'cripto',
      priority: 'medium'
    },
    {
      title: "Fitch ratifica calificación crediticia de Colombia en BBB-",
      description: "La calificadora mantuvo la perspectiva estable para el país, destacando el desempeño de las instituciones fiscales y la sostenibilidad de la deuda.",
      url: "#",
      source: "Bloomberg",
      publishedAt: new Date(Date.now() - Math.random() * 25200000).toISOString(),
      urlToImage: "/images/financial-news.jpg",
      category: 'internacional',
      priority: 'high'
    },
    {
      title: "Nutresa diversifica portafolio con adquisición en Ecuador",
      description: "El gigante alimentario colombiano compró una empresa ecuatoriana de snacks saludables por $150 millones, expandiendo su presencia regional.",
      url: "#",
      source: "Dinero",
      publishedAt: new Date(Date.now() - Math.random() * 28800000).toISOString(),
      urlToImage: "/images/investments.png",
      category: 'empresas',
      priority: 'low'
    },
    {
      title: "Mercado inmobiliario colombiano muestra signos de recuperación",
      description: "Las ventas de vivienda nueva aumentaron 12% en el primer trimestre, impulsadas por subsidios gubernamentales y mejores condiciones de financiación.",
      url: "#",
      source: "Coordenada Urbana",
      publishedAt: new Date(Date.now() - Math.random() * 32400000).toISOString(),
      urlToImage: "/images/real-estate.png",
      category: 'economia',
      priority: 'medium'
    },
    {
      title: "Colombia se posiciona como hub fintech en Latinoamérica",
      description: "El país atrajo $500 millones en inversión fintech en 2024, consolidándose como el segundo mercado más atractivo de la región después de Brasil.",
      url: "#",
      source: "Fintech Americas",
      publishedAt: new Date(Date.now() - Math.random() * 36000000).toISOString(),
      urlToImage: "/images/financial-assistant.jpg",
      category: 'empresas',
      priority: 'medium'
    }
  ];

  const updateNews = () => {
    setIsLoading(true);
    
    setTimeout(() => {
      // Simular nueva información con timestamps actualizados
      const updatedNews = simulatedNews.map(article => ({
        ...article,
        publishedAt: new Date(Date.now() - Math.random() * 43200000).toISOString()
      }));
      
      setNews(updatedNews.sort((a, b) => 
        new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
      ));
      setLastUpdate(new Date());
      setIsLoading(false);
    }, 1000);
  };

  useEffect(() => {
    updateNews();
  }, []);

  const getTimeAgo = (dateString: string) => {
    const now = new Date();
    const articleDate = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `hace ${diffInMinutes} min`;
    } else if (diffInMinutes < 1440) {
      return `hace ${Math.floor(diffInMinutes / 60)} h`;
    } else {
      return `hace ${Math.floor(diffInMinutes / 1440)} d`;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'economia': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'bolsa': return 'bg-green-50 text-green-700 border-green-200';
      case 'empresas': return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'internacional': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'cripto': return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      default: return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'economia': return DollarSign;
      case 'bolsa': return TrendingUp;
      case 'empresas': return Globe;
      case 'internacional': return ExternalLink;
      case 'cripto': return TrendingDown;
      default: return Newspaper;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high': return { label: 'Destacada', className: 'bg-red-100 text-red-800' };
      case 'medium': return { label: 'Importante', className: 'bg-yellow-100 text-yellow-800' };
      case 'low': return { label: 'General', className: 'bg-gray-100 text-gray-800' };
      default: return { label: 'General', className: 'bg-gray-100 text-gray-800' };
    }
  };

  const filterByCategory = (category: string) => {
    if (category === 'todas') return news;
    return news.filter(article => article.category === category);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Noticias Financieras</h1>
          <p className="text-gray-600 mt-1">
            Mantente informado de las últimas noticias económicas y financieras
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right text-sm">
            <p className="text-gray-500">Última actualización</p>
            <p className="font-medium text-gray-900">
              {lastUpdate.toLocaleTimeString('es-CO')}
            </p>
          </div>
          <Button 
            onClick={updateNews} 
            disabled={isLoading}
            size="sm"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            {isLoading ? 'Actualizando...' : 'Actualizar'}
          </Button>
        </div>
      </div>

      {/* Información sobre la fuente */}
      <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Newspaper className="w-8 h-8 text-blue-600" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-1">Centro de Noticias Financieras</h3>
              <p className="text-sm text-blue-700">
                Noticias simuladas para demostración. En un entorno real, estas se obtendrían 
                de APIs como NewsAPI, con fuentes como Portafolio, La República, Bloomberg y Reuters.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="todas" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="todas">Todas</TabsTrigger>
          <TabsTrigger value="economia">Economía</TabsTrigger>
          <TabsTrigger value="bolsa">Bolsa</TabsTrigger>
          <TabsTrigger value="empresas">Empresas</TabsTrigger>
          <TabsTrigger value="internacional">Internacional</TabsTrigger>
          <TabsTrigger value="cripto">Cripto</TabsTrigger>
        </TabsList>

        {['todas', 'economia', 'bolsa', 'empresas', 'internacional', 'cripto'].map(category => (
          <TabsContent key={category} value={category} className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {filterByCategory(category).map((article, index) => {
                const CategoryIcon = getCategoryIcon(article.category);
                const priorityBadge = getPriorityBadge(article.priority);
                
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={getCategoryColor(article.category)}>
                              <CategoryIcon className="w-3 h-3 mr-1" />
                              {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
                            </Badge>
                            {article.priority === 'high' && (
                              <Badge className={priorityBadge.className}>
                                {priorityBadge.label}
                              </Badge>
                            )}
                          </div>
                          <CardTitle className="text-lg leading-tight">
                            {article.title}
                          </CardTitle>
                        </div>
                        {article.urlToImage && (
                          <img 
                            src={article.urlToImage} 
                            alt=""
                            className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                          />
                        )}
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <p className="text-gray-600 text-sm leading-relaxed">
                        {article.description}
                      </p>
                      
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-3 text-gray-500">
                          <span className="font-medium">{article.source}</span>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {getTimeAgo(article.publishedAt)}
                          </div>
                        </div>
                        <Button size="sm" variant="outline">
                          <ExternalLink className="w-3 h-3 mr-1" />
                          Leer más
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            
            {filterByCategory(category).length === 0 && (
              <Card>
                <CardContent className="p-8 text-center">
                  <Newspaper className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    No hay noticias en esta categoría
                  </h3>
                  <p className="text-gray-600">
                    Intenta con otra categoría o actualiza las noticias.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* Resumen de mercado */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Resumen del Mercado
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">+2.3%</div>
              <div className="text-sm text-gray-600">COLCAP (Simulado)</div>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">5.8%</div>
              <div className="text-sm text-gray-600">Inflación Anual</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">10.75%</div>
              <div className="text-sm text-gray-600">Tasa Banrep</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <Card className="border-yellow-200 bg-yellow-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Filter className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <p className="font-medium text-yellow-800 mb-1">Contenido Simulado</p>
              <p className="text-yellow-700">
                Las noticias mostradas son simuladas con fines educativos. Para información 
                financiera real y actualizada, consulta fuentes oficiales como Portafolio, 
                La República, Bloomberg, o el sitio web del Banco de la República.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FinancialNews;
