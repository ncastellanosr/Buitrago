import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  Search,
  Clock,
  BarChart3,
  Activity
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Stock } from '../types';

interface StockPrice extends Stock {
  currentPrice: number;
  change: number;
  changePercent: number;
  volume: number;
  high: number;
  low: number;
  lastUpdate: Date;
}

const StockPrices: React.FC = () => {
  const [stocks, setStocks] = useState<StockPrice[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState(false);

  // Simular datos de precios de acciones colombianas
  const colombianStocks: Omit<StockPrice, 'currentPrice' | 'change' | 'changePercent' | 'volume' | 'high' | 'low' | 'lastUpdate'>[] = [
    {
      id: 'ecopetrol',
      symbol: 'ECOPETROL',
      name: 'Ecopetrol S.A.',
      sector: 'Energía',
      description: 'Empresa petrolera más grande de Colombia',
      riskLevel: 'Medio',
      advantages: ['Líder del sector', 'Dividendos atractivos', 'Respaldo estatal'],
      disadvantages: ['Dependiente del precio del petróleo', 'Riesgo regulatorio']
    },
    {
      id: 'grupoargos',
      symbol: 'GRUPOARGOS',
      name: 'Grupo Argos S.A.',
      sector: 'Materiales',
      description: 'Holding de inversiones en cemento, energía e infraestructura',
      riskLevel: 'Medio',
      advantages: ['Diversificación sectorial', 'Presencia regional', 'Sólida administración'],
      disadvantages: ['Exposición a ciclos económicos', 'Complejidad del holding']
    },
    {
      id: 'bancolombia',
      symbol: 'BANCOLOMBIA',
      name: 'Bancolombia S.A.',
      sector: 'Financiero',
      description: 'Principal grupo financiero de Colombia',
      riskLevel: 'Bajo',
      advantages: ['Líder del sector financiero', 'Diversificación geográfica', 'Tecnología avanzada'],
      disadvantages: ['Riesgo crediticio', 'Regulación bancaria estricta']
    },
    {
      id: 'grupoaval',
      symbol: 'GRUPOAVAL',
      name: 'Grupo Aval Acciones y Valores S.A.',
      sector: 'Financiero',
      description: 'Conglomerado financiero más grande de Colombia',
      riskLevel: 'Bajo',
      advantages: ['Mayor grupo financiero', 'Diversificación de servicios', 'Amplia cobertura'],
      disadvantages: ['Exposición al sector financiero', 'Riesgo regulatorio']
    },
    {
      id: 'isagen',
      symbol: 'ISAGEN',
      name: 'ISAGEN S.A. E.S.P.',
      sector: 'Servicios Públicos',
      description: 'Empresa de generación de energía eléctrica',
      riskLevel: 'Medio',
      advantages: ['Sector estable', 'Demanda constante', 'Tecnología limpia'],
      disadvantages: ['Regulación energética', 'Dependiente del clima']
    },
    {
      id: 'nutresa',
      symbol: 'NUTRESA',
      name: 'Grupo Nutresa S.A.',
      sector: 'Consumo',
      description: 'Empresa líder en alimentos procesados',
      riskLevel: 'Bajo',
      advantages: ['Sector defensivo', 'Marcas reconocidas', 'Expansión regional'],
      disadvantages: ['Competencia intensa', 'Costos de materias primas']
    }
  ];

  // Generar precios aleatorios realistas
  const generateRandomPrice = (basePrice: number, volatility: number = 0.02) => {
    const change = (Math.random() - 0.5) * basePrice * volatility;
    return Math.max(basePrice + change, basePrice * 0.5); // Evitar precios negativos
  };

  const basePrices: Record<string, number> = {
    'ECOPETROL': 2450,
    'GRUPOARGOS': 12800,
    'BANCOLOMBIA': 28500,
    'GRUPOAVAL': 1180,
    'ISAGEN': 2850,
    'NUTRESA': 24200
  };

  const updateStockPrices = () => {
    setIsLoading(true);
    
    setTimeout(() => {
      const updatedStocks = colombianStocks.map(stock => {
        const basePrice = basePrices[stock.symbol] || 1000;
        const currentPrice = generateRandomPrice(basePrice, 0.015);
        const previousPrice = basePrice;
        const change = currentPrice - previousPrice;
        const changePercent = (change / previousPrice) * 100;
        
        return {
          ...stock,
          currentPrice,
          change,
          changePercent,
          volume: Math.floor(Math.random() * 1000000) + 100000,
          high: currentPrice * (1 + Math.random() * 0.03),
          low: currentPrice * (1 - Math.random() * 0.03),
          lastUpdate: new Date()
        };
      });
      
      setStocks(updatedStocks);
      setLastUpdate(new Date());
      setIsLoading(false);
    }, 1500);
  };

  useEffect(() => {
    updateStockPrices();
    
    // Actualizar precios cada 30 segundos
    const interval = setInterval(updateStockPrices, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatVolume = (volume: number) => {
    if (volume >= 1000000) {
      return `${(volume / 1000000).toFixed(1)}M`;
    }
    if (volume >= 1000) {
      return `${(volume / 1000).toFixed(0)}K`;
    }
    return volume.toString();
  };

  const filteredStocks = stocks.filter(stock => 
    stock.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
    stock.sector.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel.toLowerCase()) {
      case 'bajo': return 'text-green-600 bg-green-50 border-green-200';
      case 'medio': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'alto': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Precios de Acciones</h1>
          <p className="text-gray-600 mt-1">
            Cotizaciones del mercado colombiano actualizadas automáticamente
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right text-sm">
            <p className="text-gray-500">Última actualización</p>
            <p className="font-medium text-gray-900">
              {lastUpdate.toLocaleTimeString('es-CO')}
            </p>
          </div>
          <Button 
            onClick={updateStockPrices} 
            disabled={isLoading}
            size="sm"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            {isLoading ? 'Actualizando...' : 'Actualizar'}
          </Button>
        </div>
      </div>

      {/* Información del Mercado */}
      <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <BarChart3 className="w-8 h-8 text-blue-600" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-1">Bolsa de Valores de Colombia (BVC)</h3>
              <p className="text-sm text-blue-700">
                Los precios mostrados son simulados con fines educativos. En un entorno real, 
                estos datos se obtendrían de APIs financieras como Yahoo Finance o Alpha Vantage.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Barra de búsqueda */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Buscar por nombre, símbolo o sector..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Activity className="w-4 h-4" />
          <span>{filteredStocks.length} acciones</span>
        </div>
      </div>

      {/* Lista de Acciones */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredStocks.map((stock) => (
          <Card key={stock.symbol} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">{stock.symbol}</CardTitle>
                  <p className="text-sm text-gray-600">{stock.name}</p>
                  <Badge variant="outline" className="mt-1 text-xs">
                    {stock.sector}
                  </Badge>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-gray-900">
                    {formatCurrency(stock.currentPrice)}
                  </div>
                  <div className={`flex items-center gap-1 text-sm ${
                    stock.change >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {stock.change >= 0 ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    <span>
                      {stock.change >= 0 ? '+' : ''}{formatCurrency(stock.change)}
                    </span>
                    <span>
                      ({stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">{stock.description}</p>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Máximo:</span>
                  <span className="font-medium ml-2">{formatCurrency(stock.high)}</span>
                </div>
                <div>
                  <span className="text-gray-500">Mínimo:</span>
                  <span className="font-medium ml-2">{formatCurrency(stock.low)}</span>
                </div>
                <div>
                  <span className="text-gray-500">Volumen:</span>
                  <span className="font-medium ml-2">{formatVolume(stock.volume)}</span>
                </div>
                <div>
                  <span className="text-gray-500">Riesgo:</span>
                  <Badge className={`ml-2 text-xs ${getRiskColor(stock.riskLevel)}`}>
                    {stock.riskLevel}
                  </Badge>
                </div>
              </div>

              <div className="space-y-2">
                <div>
                  <h4 className="text-sm font-medium text-green-700 mb-1">Ventajas</h4>
                  <ul className="text-xs text-gray-600 space-y-0.5">
                    {stock.advantages.slice(0, 2).map((advantage, index) => (
                      <li key={index}>• {advantage}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t">
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  {stock.lastUpdate.toLocaleTimeString('es-CO')}
                </div>
                <Button size="sm" variant="outline">
                  Ver Análisis
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredStocks.length === 0 && searchTerm && (
        <Card>
          <CardContent className="p-8 text-center">
            <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              No se encontraron resultados
            </h3>
            <p className="text-gray-600">
              No hay acciones que coincidan con "{searchTerm}". 
              Intenta con otro término de búsqueda.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Disclaimer */}
      <Card className="border-yellow-200 bg-yellow-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Activity className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <p className="font-medium text-yellow-800 mb-1">Aviso Importante</p>
              <p className="text-yellow-700">
                Los precios mostrados son simulados con fines educativos y demostrativos. 
                Para inversiones reales, consulta fuentes oficiales como la Bolsa de Valores de Colombia 
                o plataformas de trading autorizadas. Las inversiones en acciones conllevan riesgos 
                y es recomendable consultar con un asesor financiero.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StockPrices;
