import React, { useEffect } from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import BudgetCalculator from './components/BudgetCalculator';
import Investments from './components/Investments';
import StockPrices from './components/StockPrices';
import FinancialNews from './components/FinancialNews';
import EducationalAssistant from './components/EducationalAssistant';
import './App.css'

const AppContent: React.FC = () => {
  const { state, dispatch } = useApp();

  // Detectar selección de texto para el asistente educativo
  useEffect(() => {
    const handleTextSelection = () => {
      const selection = window.getSelection();
      if (selection && selection.toString().trim().length > 0) {
        const selectedText = selection.toString().trim().toLowerCase();
        dispatch({ type: 'SET_SELECTED_TEXT', payload: selectedText });
        
        // Verificar si el texto seleccionado es un término financiero
        if (state.educationalContent?.terms[selectedText]) {
          dispatch({ type: 'TOGGLE_ASSISTANT' });
        }
      }
    };

    document.addEventListener('mouseup', handleTextSelection);
    return () => document.removeEventListener('mouseup', handleTextSelection);
  }, [state.educationalContent, dispatch]);

  const renderCurrentView = () => {
    switch (state.currentView) {
      case 'budget':
        return <BudgetCalculator />;
      case 'investments':
        return <Investments />;
      case 'stocks':
        return <StockPrices />;
      case 'news':
        return <FinancialNews />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6 ml-64">
          {renderCurrentView()}
        </main>
      </div>
      {state.showAssistant && (
        <EducationalAssistant 
          selectedText={state.selectedText}
          onClose={() => dispatch({ type: 'TOGGLE_ASSISTANT' })}
        />
      )}
    </div>
  );
};

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;
